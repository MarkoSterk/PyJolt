"""
exceptions subpackage
"""

from .exception_handler import Handler

__all__ = ["Handler"]
