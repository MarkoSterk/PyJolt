"""
PyScript module
"""
from .pyscript import PyScript

__all__ = ['PyScript']
