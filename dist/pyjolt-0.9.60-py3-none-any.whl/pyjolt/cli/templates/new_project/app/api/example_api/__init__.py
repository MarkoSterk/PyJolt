"""
Test api subpackage
"""
from .example_api import ExampleApi

__all__ = ["ExampleApi"]
