"""CLI utility script"""
from app import Application

if __name__ == "__main__":
    app = Application()
    app.run_cli()
