"""
Cli methods
"""
from .cli import main

__all__ = ['main']
