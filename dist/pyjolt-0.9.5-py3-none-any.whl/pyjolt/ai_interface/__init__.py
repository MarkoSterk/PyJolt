"""
Ai interface module
"""
from .ai_interface import AiInterface

__all__ = ['AiInterface']
