"""
Desktop UI for creating desktop application
Utilizes cefpzthon3 under the hood
"""
from .desktop_ui import DesktopUI

__all__ = ['DesktopUI']
