"""
CORS module
"""
from .CORSMiddleware import CORSMiddleware

__all__ = ['CORSMiddleware']
