"""
PyJolt default logger
"""
from .logging.logger_config_base import LoggerBase

class DefaultLogger(LoggerBase):
    """Default logger implementation"""
