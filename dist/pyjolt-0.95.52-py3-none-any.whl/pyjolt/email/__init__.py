"""
Email client module for sending emails using SMTP.
"""
from .email_client import EmailClient

__all__ = ["EmailClient"]
