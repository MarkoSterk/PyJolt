"""Admin dashboard package."""
