"""
App models
"""
from .example_model import Example

__all__ = ["Example"]
