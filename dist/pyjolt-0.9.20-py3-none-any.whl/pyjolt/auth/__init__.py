"""
Authentication module
"""

from .authentication import Authentication

__all__ = ['Authentication']
